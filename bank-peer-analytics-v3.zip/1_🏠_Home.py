import streamlit as st ###### Import Streamlit library
from configparser import ConfigParser ###### Import ConfigParser library for reading config file to get model, greeting message, etc.
from PIL import Image ###### Import Image library for loading images
import os ###### Import os library for environment variables
from utils import * ###### Import custom utility functions from utils.py

    # Custom column layout with increased width for col1 and col3, and moving them down by 20pt
config_object = ConfigParser()
config_object.read("bank_config.ini")
hline=Image.open(config_object["IMAGES"]["hline"]) ###### image for formatting landing screen

#st.set_page_config(page_title="My App", layout="wide")
st.set_page_config(layout="wide", page_title="BankIQ") ###### Removed the Page icon

#### Set Logo on top sidebar ####
st.sidebar.image(hline) ###### Add horizontal line
c1,c2,c3=st.sidebar.columns([1,3,1]) ###### Create columns
st.sidebar.image(hline) ###### Add horizontal line
##
st.markdown(
    """
    <style>
        [data-testid=stSidebar]{
            text-align: center;
            display: block;
            margin-left: auto;
            margin-right: auto;
            width: 100%;
        }
    </style>
    """, unsafe_allow_html=True
)
sidebar_title = '<p style="font-family:Amazon Ember; color:#FF9900; font-size: 30px; "><b>Amazon Bedrock Powered - BankIQ+</b></p>'
st.sidebar.markdown(sidebar_title, unsafe_allow_html=True)

##

st.sidebar.image(hline) ###### Add horizontal line
st.sidebar.image(hline) ###### Add horizontal line



st.image(hline)
heads()
st.image(hline)
col1, col2, col3,col5,col4=st.columns([10,1,10,1,10])
col1, col2, col5,col4=st.columns([10,1,1,10])
with col1:
    first_column()
with col2:
    st.write("")

with col5:
    st.write("")
with col4:
    third_column()
st.image(hline)

#### Contact Information ####
with st.sidebar.expander("📬 __Contact__"):
    st.image(hline)
    contact()
    st.image(hline)
st.sidebar.image(hline)
