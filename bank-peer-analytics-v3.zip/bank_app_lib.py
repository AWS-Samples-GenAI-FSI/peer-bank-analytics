from langchain_community.embeddings import BedrockEmbeddings
from langchain.indexes import VectorstoreIndexCreator
from langchain_community.vectorstores import FAISS
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader
from langchain_community.llms import Bedrock


# def get_llm():
    
#     # model_kwargs = { #AI21
#     #     "maxTokens": 1024, 
#     #     "temperature": 0, 
#     #     "topP": 0.5, 
#     #     "stopSequences": [], 
#     #     "countPenalty": {"scale": 0 }, 
#     #     "presencePenalty": {"scale": 0 }, 
#     #     "frequencyPenalty": {"scale": 0 } 
#     # }
    
#     prompt = """
#             Assume you are a banking analyst and you need to summarize how the base bank is doing in-terms of 
#             performance of the metric "CRE Concentration Ratio (%)" against its peers across all the 4 quarters.  
#             Generate more insights and compare it and explicitly specify how its better or worse when compared to 
#             its peers.
            
#             Assistant:"""
    
#     model_kwargs = {
#             "prompt": prompt,
#             "max_tokens_to_sample":4096,
#             "temperature":0.5,
#             "top_k":250,
#              "top_p":0.5,
#              "stop_sequences":[]
#              }
    
#     llm = Bedrock(
#         model_id="anthropic.claude-v2", #set the foundation model
#         model_kwargs=model_kwargs) #configure the inference parameters
    
#     return llm



def get_llm():
    
    model_kwargs = {
        "max_tokens": 4000,
        "temperature": 0,
        "p": 0.01,
        "k": 0,
        "stop_sequences": [],
        "return_likelihoods": "NONE"
    }
    
    llm = Bedrock(
        model_id="cohere.command-text-v14", #set the foundation model
        model_kwargs=model_kwargs) #configure the inference parameters
    
    return llm




def get_index(): #creates and returns an in-memory vector store to be used in the application
    
    embeddings = BedrockEmbeddings() #create a Titan Embeddings client
    
    pdf_path = "quarterly_consolidated_file.pdf" #assumes local PDF file with this name
    #pdf_path = "2022-Shareholder-Letter.pdf" #assumes local PDF file with this name

    loader = PyPDFLoader(file_path=pdf_path) #load the pdf file
    
    text_splitter = RecursiveCharacterTextSplitter( #create a text splitter
        separators=["\n\n", "\n", ".", " "], #split chunks at (1) paragraph, (2) line, (3) sentence, or (4) word, in that order
        chunk_size=1000, #divide into 1000-character chunks using the separators above
        chunk_overlap=100 #number of characters that can overlap with previous chunk
    )
    
    index_creator = VectorstoreIndexCreator( #create a vector store factory
        vectorstore_cls=FAISS, #use an in-memory vector store for demo purposes
        embedding=embeddings, #use Titan embeddings
        text_splitter=text_splitter, #use the recursive text splitter
    )
    
    index_from_loader = index_creator.from_loaders([loader]) #create an vector store index from the loaded PDF
    
    return index_from_loader #return the index to be cached by the client app


def get_rag_response(index, question): #rag client function
    
    llm = get_llm()
    
    response_text = index.query(question=question, llm=llm) #search against the in-memory index, stuff results into a prompt and send to the llm
    
    return response_text