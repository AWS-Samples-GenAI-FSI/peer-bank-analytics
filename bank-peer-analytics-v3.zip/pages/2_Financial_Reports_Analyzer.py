import os
import nest_asyncio
import io
import PyPDF2

def run_app():
    nest_asyncio.apply()
    
    from llama_index.core import VectorStoreIndex, SimpleDirectoryReader, StorageContext, load_index_from_storage, ServiceContext
    
    
    from llama_index.core.tools import QueryEngineTool, ToolMetadata
    from llama_index.core.query_engine import SubQuestionQueryEngine
    from llama_index.core.callbacks import CallbackManager, LlamaDebugHandler
    from llama_index.core import Settings
    from llama_index.embeddings.bedrock import BedrockEmbedding
    from llama_index.core.node_parser import UnstructuredElementNodeParser
    from llama_index.core.schema import Document
    from langchain_core.prompts import PromptTemplate
    #from llama_index.question_gen.guidance import GuidanceQuestionGenerator
    from llama_index.core.question_gen import LLMQuestionGenerator
    
    ## For Amazon Bedrock
    from llama_index.core.settings import Settings
    from llama_index.llms.bedrock import Bedrock
    from llama_index.embeddings.bedrock import BedrockEmbedding, Models
    
    llm = Bedrock(model= "anthropic.claude-3-sonnet-20240229-v1:0")
    embed_model = BedrockEmbedding(model = "amazon.titan-embed-g1-text-02")
    
    
    
    llama_debug = LlamaDebugHandler(print_trace_on_end=True)
    callback_manager = CallbackManager([llama_debug])
    
    Settings.callback_manager = callback_manager
    
    Settings.llm = llm
    Settings.embed_model = embed_model
    
    from src.fields2 import (
        fiscal_year, fiscal_year_attributes,
        strat_outlook, strat_outlook_attributes,
        risk_management, risk_management_attributes,
        innovation, innovation_attributes
    )
    
    import streamlit as st
    import os
    import time
    from pypdf import PdfReader
    import nltk
    nltk.download('punkt')
    # import nltk
    # nltk.download()
    
    #######
    s3_bucket_name = "genai-demo-outout-6915" ## Change it as per your environment
    common_bucket_prefix = "BankName"
    #######
    # st.set_page_config(page_title="Annual Report Analyzer", page_icon=":card_index_dividers:", initial_sidebar_state="expanded", layout="wide")
    st.title(":card_index_dividers: Financial Reports Analyzer")
    
    def listFiles(s3_bucket_name,bucket_prefix):
        import boto3
        s3 = boto3.client('s3')
        file_list = []
        
        paginator = s3.get_paginator('list_objects_v2')
        for result in paginator.paginate(Bucket=s3_bucket_name,Prefix=bucket_prefix+"/"):
            
            if result.get('Contents') is not None:
               for obj in result['Contents']:
                   file_list.append(obj['Key'])
            else:
                 st.sidebar.write("No files in S3 bucket. Upload file first")
    
        return file_list
    
    def get_filenames(s3_bucket_name,prefix):
        filenames = []
        import boto3
        s3 = boto3.client('s3')
        result = s3.list_objects_v2(Bucket=s3_bucket_name, Prefix=prefix)
        for item in result['Contents']:
            files = item['Key']
    
            if files.endswith('.pdf'):
                final_file_name = files.replace(prefix, '')
                filenames.append(final_file_name)   #optional if you have more filefolders to got through.
        return filenames
    
    
    def list_folders(s3_client, bucket_name):
        import boto3
        s3_client = boto3.client('s3')
        response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix='BankName/',Delimiter='/')
        for content in response.get('CommonPrefixes', []):
            #yield content.get('Prefix').replace('BankName/', '')
            yield content.get('Prefix')
    
    
    
    
    def process_pdf_new(pdf,s3_bucket_name,prefix_string):
        s3=boto3.resource("s3")
        pdf_bytes = io.BytesIO()
        
        pdf_filename = prefix_string + pdf
        s3.Bucket(s3_bucket_name).download_fileobj(pdf_filename, pdf_bytes)
        pdf_reader = PyPDF2.PdfReader(pdf_bytes)
        # Get the number of pages in the PDF
        num_pages = len(pdf_reader.pages)
        # Extract text from each page
        document_list = []
        for page in pdf_reader.pages:
            document_list.append(Document(text=str(page.extract_text())))
    
        node_paser = UnstructuredElementNodeParser()
        nodes = node_paser.get_nodes_from_documents(document_list, show_progress=True)
        return nodes
        
    def process_pdf(pdf):
        file = PdfReader(pdf)
    
        document_list = []
        for page in file.pages:
            document_list.append(Document(text=str(page.extract_text())))
        node_paser = UnstructuredElementNodeParser()
        nodes = node_paser.get_nodes_from_documents(document_list, show_progress=True)
        return nodes
    
    
    def get_vector_index(nodes, vector_store):
        if vector_store == "simple":
            service_context = ServiceContext.from_defaults(llm=Settings.llm,embed_model=Settings.embed_model)
            index = VectorStoreIndex(
                nodes=nodes,
                service_context=service_context
            )
        return index
    
    
    def generate_insight(engine, insight_name, section_name):
    
        with open("prompts/report.prompt", "r") as f:
            template = f.read()
    
    
        response = engine.query(section_name)
        return response.response
    
    
    def report_insights(engine, section_name, fields_to_include, section_num):
        fields = None
        attribs = None
    
        if section_num == 1:
            fields = fiscal_year
            attribs = fiscal_year_attributes
        elif section_num == 2:
            fields = strat_outlook
            attribs = strat_outlook_attributes
        elif section_num == 3:
            fields = risk_management
            attribs = risk_management_attributes
        elif section_num == 4:
            fields = innovation
            attribs = innovation_attributes
    
        ins = {}
        for i, field in enumerate(attribs):
            print(fields_to_include[i])
            if fields_to_include[i]:
                print(str({field: fields[field]}))
                response = generate_insight(engine, field, fields[field])
                print(response)
                ins[field] = response
    
        return {
            "insights": ins
        }
    
    def get_query_engine(engine):
        service_context = ServiceContext.from_defaults(llm=llm,embed_model=embed_model)
        
        query_engine_tools = [
            QueryEngineTool(
                query_engine=engine,
                metadata=ToolMetadata(
                    name="Annual Report",
                    description="Provides information about the company from its annual report.",
                ),
            ),
        ]
    
        s_engine = SubQuestionQueryEngine.from_defaults(query_engine_tools=query_engine_tools, question_gen=LLMQuestionGenerator.from_defaults(service_context=service_context))
    
        return s_engine
    
    
    for insight in fiscal_year_attributes:
        if insight not in st.session_state:
            st.session_state[insight] = None
    
    for insight in strat_outlook_attributes:
        if insight not in st.session_state:
            st.session_state[insight] = None
    
    for insight in risk_management_attributes:
        if insight not in st.session_state:
            st.session_state[insight] = None
    
    for insight in innovation_attributes:
        if insight not in st.session_state:
            st.session_state[insight] = None
    
    if "end_time" not in st.session_state:
        st.session_state.end_time = None
    
    
    if "process_doc" not in st.session_state:
            st.session_state.process_doc = False
    
    
    
    import boto3
    s3_client = boto3.client("s3")
    #bank_name = list_folders(s3_client, "genai-demo-outout-6915")
    bank_name = list_folders(s3_client, s3_bucket_name)
    list_of_banks = []
    for banks in bank_name:
        bank1 = banks.replace('BankName/', '')
        bank2 = bank1.replace('/', '')
        list_of_banks.append(bank2)
    
    
    #selected_bank = st.sidebar.selectbox("Select a Bank", list_of_banks, placeholder="Select a Bank from the list", index=1,on_change=clear)
    #selected_bank = st.sidebar.selectbox("Select a Bank", list_of_banks, placeholder="Select a Bank from the list", index=1)
    selected_bank = st.sidebar.selectbox("#### :blue[Select a Bank]", list_of_banks, placeholder="Select a Bank from the list", index=1)
    type_of_report = st.sidebar.radio("#### :blue[Select the type of report]", ("Annual Report", "Quarterly Report"))
    if type_of_report == "Annual Report":
        report_type = "10kReport/"
    else:
        report_type = "10QReport/"
    
    report_file_name = "BankName/" + selected_bank + "/" + report_type
    prefix_string  = selected_bank + "/" + report_type
    
    
    file_list = get_filenames(s3_bucket_name,report_file_name)
    
    
    #selected_file = st.sidebar.selectbox("Select a file from S3 bucket", file_list, placeholder="Select a file from S3 bucket", index=0,on_change=clear)
    selected_file = st.sidebar.selectbox("#### :blue[Select the report]", file_list, placeholder="Select a file from S3 bucket", index=0)
    st.write("You selected: ", selected_file)
    pdfs = selected_file 
    
    
    if st.sidebar.button("Process Document"):
            with st.spinner("Processing Document..."):
    
                nodes = process_pdf_new(pdfs, s3_bucket_name, report_file_name)
                print(nodes)
                st.session_state.index = get_vector_index(nodes, vector_store="simple")
                #query_engine = st.session_state.index.as_query_engine(similarity_top_k=3)
                #response = query_engine.query("What company is being referred and what it is doing?")
                #print(response)
    
                st.session_state.process_doc = True
     
            st.toast("Document Processsed!")
    
    
    if st.session_state.process_doc:
            print("Session state for process document is True...")
            col1, col2 = st.columns([0.25, 0.75])
    
            with col1:
                st.write("""
                    ### Select Insights
                """)
                
    
                fiscal_year_highlights_list = ["performance_highlights"]
    
    
                strategy_outlook_future_direction_list = ["strategic_initiatives"]
    
                risk_management_list = ["risk_factors"]
    
    
                innovation_and_rd_list = ["r_and_d_activities"]
    
            with col2:
                #if st.button("Analyze Report"):
                engine = get_query_engine(st.session_state.index.as_query_engine(similarity_top_k=3))
                start_time = time.time()
    
                with st.status("**Analyzing Report...**"):
                    if any(fiscal_year_highlights_list):
                        st.write("Fiscal Year Highlights...")
    
    
                        response = report_insights(engine, "Fiscal Year Highlights", fiscal_year_highlights_list, 1)
    
                        for key, value in response["insights"].items():
                            st.session_state[key] = value
    
                        if any(strategy_outlook_future_direction_list):
                            st.write("Strategy Outlook and Future Direction...")
    
                            response = report_insights(engine, "Strategy Outlook and Future Direction", strategy_outlook_future_direction_list, 2)
    
                            for key, value in response["insights"].items():
                                st.session_state[key] = value
    
    
                        if any(risk_management_list):
                            st.write("Risk Management...")
    
                            
                            response = report_insights(engine, "Risk Management", risk_management_list, 3)
    
                            for key, value in response["insights"].items():
                                st.session_state[key] = value
    
                        if any(innovation_and_rd_list):
                            st.write("Innovation and R&D...")
    
                            response = report_insights(engine, "Innovation and R&D", innovation_and_rd_list, 4)
                            st.session_state.innovation_and_rd = response
    
                            for key, value in response["insights"].items():
                                st.session_state[key] = value
    
    
                    st.session_state["end_time"] = "{:.2f}".format((time.time() - start_time))
                    st.toast("Report Analysis Complete!")
                
            if st.session_state.end_time:
                st.write("Report Analysis Time: ", st.session_state.end_time, "s")
    
    
                
            tab1, tab2, tab3, tab4 = st.tabs(["Fiscal Year Highlights", "Strategy Outlook and Future Direction", "Risk Management", "Innovation and R&D"])
    
            with tab1:
                st.write("## Fiscal Year Highlights")
                try: 
    
                    st.write("### Performance Highlights")
                    st.write(st.session_state['performance_highlights'])
                except:
                    st.error("This insight has not been generated")
    
                with tab2:
                    st.write("## Strategy Outlook and Future Direction")
                    try:
    
                        st.write("### Strategic Initiatives")
                        st.write(st.session_state["strategic_initiatives"])
                    except:
                        st.error("This insight has not been generated")
    
                with tab3:
                    st.write("## Risk Management")
                    try:
    
                        st.write("### Risk Factors")
                        st.write(st.session_state["risk_factors"])
                    except:
                        st.error("This insight has not been generated")
    
                with tab4:
                    st.write("## Innovation and R&D")
                    try:
                        st.write("### R&D Activities")
                        st.write(st.session_state["r_and_d_activities"])
                    except:
                        st.error("This insight has not been generated")

            
if __name__ == "__main__":
    run_app()