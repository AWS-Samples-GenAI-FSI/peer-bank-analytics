import streamlit as st
import pandas as pd
import plotly.express as px
import base64
from datetime import datetime
import io
import base64
import bank_app_lib as glib  # reference to local lib script
from configparser import ConfigParser ###### Import ConfigParser library for reading config file to get model, greeting message, etc.
from PIL import Image ###### Import Image library for loading images
import os ###### Import os library for environment variables
from utils import * ###### Import custom utility functions from utils.py

config_object = ConfigParser()
config_object.read("bank_config.ini")
hline=Image.open(config_object["IMAGES"]["hline"]) ###### image for formatting landing screen

#st.set_page_config(page_title="My App", layout="wide")
st.set_page_config(layout="wide", page_title="BankIQ+") ###### Removed the Page icon

#### Set Logo on top sidebar ####
#st.sidebar.image(hline) ###### Add horizontal line
c1,c2,c3=st.sidebar.columns([1,3,1]) ###### Create columns


def run_app():
    # Load data (replace these with your actual data loading process)
    data_quarters = pd.read_csv("bank_data-quarter.csv")
    data_years = pd.read_csv("bank_data-year.csv")
    metric_data = pd.read_csv("metrics.csv")  # Load metric data from CSV

    # Function to generate dummy summary
    def generate_summary(df, metric, peers, period):
        summary_text = f"Dummy summary for {metric} compared to {', '.join(peers)} for {period}:\n\n"
        summary_text += "This is a placeholder summary text. You should replace this with your actual summary generation logic."
        return summary_text

    def generate_llm_output(metric):
        if 'vector_index' not in st.session_state:  # see if the vector index hasn't been created yet
            with st.spinner("Indexing document..."):  # show a spinner while the code in this with block runs
                st.session_state.vector_index = glib.get_index()  # retrieve the index through the supporting library and store in the app's session cache

        prompt = """
        Assume you are a seasoned banking analyst and as part of peer bank risk analytics, you need to analyze 
        how the base bank is performing on the metric "{}" against its two peer banks 
        across all the 4 quarters.  Generate a nicely readable summary to clearly show the variance of the base
        as compared to its peer banks to make better business decisions. Give more reasoning of if base bank 
        is performing better or not as compared to its peers on this ratio. Give the summary in bullets. Don't ask any followup questions. 
        """.format(metric)

        with st.spinner("Working..."):  # show a spinner while the code in this with block runs
            response_content = glib.get_rag_response(index=st.session_state.vector_index,
                                                     question=prompt)  # call the model through the supporting library
            return response_content

    # Streamlit app
    # st.set_page_config(page_title="Peer Bank Risk Analytics", layout="wide", initial_sidebar_state="expanded")

    # Set the theme colors
    primaryColor = "#2F4F4F"  # Dark slate gray color
    backgroundColor = "#F5FFFA"  # Mint cream background
    secondaryBackgroundColor = "#FFFAF0"  # Floral white color
    textColor = "#333333"  # Dark gray text
    font = "Arial"  # Arial font
    tile_colors = ["#00778f", "#00a897", "#02c59b", "orange"]  # Colors for tile backgrounds
    tile_text_color = "#FFFFFF"  # White text color

    def local_css(file_name):
        with open(file_name) as f:
            st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

    local_css("style.css")

    # Add custom CSS to apply the theme
    css = f"""
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Arial&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=Georgia&display=swap');
        
        body {{
            background-color: {backgroundColor};
            color: {textColor};
            font-family: '{font}', sans-serif;
        }}
        
        .stButton > button {{
            background-color: {primaryColor};
            color: white;
        }}
        
        .stButton > button:hover {{
            background-color: {primaryColor};
            color: white;
            opacity: 0.8;
        }}
        
        .sidebar .sidebar-content {{
            background-color: {secondaryBackgroundColor};
            padding: 1rem;
            border-radius: 5px;
        }}
        
        .main .block-container {{
            padding: 1rem;
            border-radius: 5px;
            background-color: white;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }}
        
        h1 {{
            color: {primaryColor};
        }}
        
        footer {{
            visibility: hidden;
        }}
        
        .sidebar-control {{
            margin-bottom: 1rem;
        }}
        
        .info-tile {{
            padding: 1rem;
            border-radius: 5px;
            margin-bottom: 1rem;
            height: 150px;  /* Set a fixed height for all tiles */
        }}
        
        .info-tile h3 {{
            padding: 0.5rem;
            border-radius: 5px;
            font-size: 1.2rem;  /* Increase font size for tile titles */
            font-weight: bold;  /* Make tile titles bold */
            color: {tile_text_color};  /* Set tile title text color */
        }}
        .info-tile h2 {{
            padding: 0.5rem;
            border-radius: 15px;
            font-size: 1.5rem;  /* Increase font size for tile titles */
            font-weight: italic;  /* Make tile titles bold */
            color: {tile_text_color};  /* Set tile title text color */
        }}        
        
        .info-tile p {{
            font-size: 1rem;  /* Increase font size for tile text */
            color: {tile_text_color};  /* Set tile text color */
        }}
        
        .summary-container {{
            background-color: {primaryColor};
            color: white;
            padding: 1rem;
            border-radius: 5px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }}
        
        .summary-title {{
            font-family: 'Georgia', serif;
            font-size: 2rem;
            font-weight: bold;
            text-align: center;
            margin-bottom: 1rem;
        }}
        
        .summary-text {{
            font-family: 'Georgia', serif;
            font-size: 1.2rem;
            line-height: 1.5;
        }}
        
        .data-table {{
            font-family: 'Arial', sans-serif;
            font-size: 0.9rem;
            border-collapse: collapse;
            width: 100%;
        }}
        
        .data-table th, .data-table td {{
            padding: 0.5rem;
            text-align: left;
            border: 1px solid {primaryColor};
        }}
        
        .data-table th {{
            background-color: {primaryColor};
            color: white;
            font-weight: bold;
        }}
        
        .data-table tr:nth-child(even) {{
            background-color: {secondaryBackgroundColor};
        }}
    </style>
    """
    st.markdown(css, unsafe_allow_html=True)

    # Add big page title
    st.markdown("<h1 style='text-align: center;'>Peer Bank Analytics</h1>", unsafe_allow_html=True)

    # Sidebar for selection controls
    # Metric selection
    metrics = metric_data["Metric Name"].tolist()
    selected_metric = st.sidebar.selectbox("#### :blue[Select a metric]", metrics, key="metric_selection",
                                           help="Select the metric to analyze.")
    selected_metric_description = metric_data.loc[metric_data["Metric Name"] == selected_metric, "Metric Description"].values[0]
   # st.sidebar.image(hline) ###### Add horizontal line
    # Display tiles
    base_bank_quarters = data_quarters[data_quarters['Bank Type'] == 'Base Bank']['Bank'].unique()[0]
    base_bank_years = data_years[data_years['Bank Type'] == 'Base Bank']['Bank'].unique()[0]
    base_bank_name = base_bank_quarters if base_bank_quarters == base_bank_years else f"{base_bank_quarters} (Quarters) / {base_bank_years} (Years)"

    peer_banks_quarters = data_quarters[data_quarters['Bank Type'] == 'Peer Bank']['Bank'].unique()
    peer_banks_years = data_years[data_years['Bank Type'] == 'Peer Bank']['Bank'].unique()
    num_peer_banks = len(peer_banks_quarters)

    num_metrics = len(metrics)

    col1, col2, col3 = st.columns(3)

    with col1:
        st.markdown(f"""
            <div class="info-tile" style="background-color: {tile_colors[0]};">
                <h2>Base Bank</h2>
                <h5>{base_bank_name}</h5>
            </div>
        """, unsafe_allow_html=True)

    with col2:
        st.markdown(f"""
            <div class="info-tile" style="background-color: {tile_colors[1]};">
                <h2>Number of Peer Banks</h2>
                <h5>{num_peer_banks}</h5>
            </div>
        """, unsafe_allow_html=True)

    with col3:
        st.markdown(f"""
            <div class="info-tile" style="background-color: {tile_colors[2]};">
                <h2>Number of Metrics</h2>
                <h5>{num_metrics}</h5>
            </div>
        """, unsafe_allow_html=True)

    # Display the fourth tile in a separate row
    col4 = st.columns(1)[0]
    with col4:
        st.markdown(f"""
            <div class="info-tile" style="background-color: {tile_colors[3]}; width: 100%;">
                <h2>{selected_metric}</h2>
                <h5>{selected_metric_description}</h5>
            </div>
        """, unsafe_allow_html=True)

    #st.sidebar.markdown("---")  # Add a horizontal line for separation
    st.sidebar.image(hline) ###### Add horizontal line
    # Peer bank selection
    peer_banks_quarters = data_quarters[data_quarters['Bank Type'] == 'Peer Bank']['Bank'].unique()
    peer_banks_years = data_years[data_years['Bank Type'] == 'Peer Bank']['Bank'].unique()
    selected_peer_banks = st.sidebar.multiselect("#### :blue[Select peer banks for comparison]", peer_banks_quarters,
                                                 default=peer_banks_quarters[:2], key="peer_bank_selection",
                                                 help="Select the peer banks to include in the comparison.")
    #st.sidebar.markdown("---")  # Add a horizontal line for separation
    st.sidebar.image(hline) ###### Add horizontal line

    # Time period selection
    period_type = st.sidebar.radio("#### :blue[Select time period type]", ["Quarters", "Years"], key="period_type_selection",
                                   help="Choose whether to analyze data by quarters or years.")
    if period_type == "Quarters":
        data = data_quarters
        base_bank = base_bank_quarters
        peer_banks = peer_banks_quarters
        quarters = data['Quarter'].unique()
        start_quarter, end_quarter = st.sidebar.select_slider("#### :blue[Select period]", options=quarters,
                                                               value=(quarters[0], quarters[-1]),
                                                               key="quarter_period_selection",
                                                               help="Select the range of quarters to analyze.")
        period = f"from {start_quarter} to {end_quarter}"
    else:
        data = data_years
        base_bank = base_bank_years
        peer_banks = peer_banks_years
        current_year = datetime.now().year
        years = [year for year in range(current_year - 3, current_year + 1) if year in data['Year'].unique()]
        if not years:
            st.warning("No data available for the current year and previous 3 years.")
            start_year, end_year = None, None
            period = ""
        else:
            start_year, end_year = st.sidebar.select_slider("Select period", options=years, value=(years[0], years[-1]),
                                                             key="year_period_selection",
                                                             help="Select the range of years to analyze.")
            period = f"from {start_year} to {end_year}"

    # Filter data based on selections
    filtered_data = data[(data['Bank'] == base_bank) | (data['Bank'].isin(selected_peer_banks))]
    filtered_data = filtered_data[filtered_data['Metric'] == selected_metric]
    if period_type == "Quarters":
        filtered_data = filtered_data[(filtered_data['Quarter'] >= start_quarter) & (filtered_data['Quarter'] <= end_quarter)]
    elif start_year and end_year:
        filtered_data = filtered_data[(filtered_data['Year'] >= start_year) & (filtered_data['Year'] <= end_year)]

    # Visualization
    if period_type == "Quarters":
        fig_line = px.line(filtered_data, x='Quarter', y='Value', color='Bank',
                           title=f"<b><span style='font-size: 24px;'>{selected_metric} Comparison ({period})</span></b>")
        fig_line.update_layout(title_font_size=24, xaxis_title='Quarter')

        # Heatmap
        pivot_data = filtered_data.pivot_table(index='Quarter', columns='Bank', values='Value', aggfunc='mean')
        fig_heatmap = px.imshow(pivot_data,
                                title=f"<b><span style='font-size: 24px;'>Heatmap for {selected_metric} ({period})</span></b>",
                                text_auto=True, x=pivot_data.columns, y=pivot_data.index)

        # Bar chart
        bar_data = filtered_data.groupby(['Bank', 'Quarter'])['Value'].mean().reset_index()
        fig_bar = px.bar(bar_data, x='Quarter', y='Value', color='Bank', barmode='group',
                         title=f"<b><span style='font-size: 24px;'>Bar Chart for {selected_metric} ({period})</span></b>")
        st.plotly_chart(fig_bar, use_container_width=True)

        # Add a horizontal line after the bar chart
        st.markdown("<hr>", unsafe_allow_html=True)

        # Display line chart and heatmap side by side
        col_line, col_heatmap = st.columns(2)
        with col_line:
            st.plotly_chart(fig_line, use_container_width=True)
        with col_heatmap:
            st.plotly_chart(fig_heatmap, use_container_width=True)

    else:
        fig_line = px.line(filtered_data, x='Year', y='Value', color='Bank',
                           title=f"<b><span style='font-size: 24px;'>{selected_metric} Comparison ({period})</span></b>")
        fig_line.update_layout(title_font_size=24, xaxis_title='Year', xaxis_tickformat='%Y')  # Display years as full integers

        # Heatmap
        pivot_data = filtered_data.pivot_table(index='Year', columns='Bank', values='Value', aggfunc='mean')
        fig_heatmap = px.imshow(pivot_data,
                                title=f"<b><span style='font-size: 24px;'>Heatmap for {selected_metric} ({period})</span></b>",
                                text_auto=True, x=pivot_data.columns, y=pivot_data.index.map(str))  # Display years as full integers

		# Bar chart
        bar_data = filtered_data.groupby(['Bank', 'Year'])['Value'].mean().reset_index()
        fig_bar = px.bar(bar_data, x='Year', y='Value', color='Bank', barmode='group',
                         title=f"<b><span style='font-size: 24px;'>Bar Chart for {selected_metric} ({period})</span></b>")
        fig_bar.update_layout(xaxis_tickformat='%Y')  # Display years as full integers
        st.plotly_chart(fig_bar, use_container_width=True)

        # Add a horizontal line after the bar chart
        st.markdown("<hr>", unsafe_allow_html=True)

        # Display line chart and heatmap side by side
        col_line, col_heatmap = st.columns(2)
        with col_line:
            st.plotly_chart(fig_line, use_container_width=True)
        with col_heatmap:
            st.plotly_chart(fig_heatmap, use_container_width=True)

    # Add another horizontal line before the summary section
    st.markdown("<hr>", unsafe_allow_html=True)

    # Summary and description
    #summary = generate_summary(filtered_data, selected_metric, selected_peer_banks, period)
    summary = generate_llm_output(selected_metric)

    st.markdown("<h2 class='summary-title' style='font-family: Tahoma; font-size: 2rem;'>Graph Summary</h2>", unsafe_allow_html=True)
    st.markdown("<p class='summary-text' style='font-family: Tahoma; font-size: 2rem;>" + summary + "</p>", unsafe_allow_html=True)
    st.markdown("</div>", unsafe_allow_html=True)

    # Add a horizontal line after the summary section
    st.markdown("<hr>", unsafe_allow_html=True)

    # Display filtered data
    st.markdown("<h2 class='input-title' style='font-family: Tahoma; font-size: 2rem; text-align: center;'>Input Data</h2>", unsafe_allow_html=True)

    col1, col2 = st.columns([1, 3])
    with col2:
        st.markdown("<div style='overflow-x: auto;'>", unsafe_allow_html=True)
        styled_data = filtered_data.style.apply(
            lambda row: ['background-color: lightblue'] * len(row) if row.name % 2 == 0 else ['background-color: #e6ffeb'] * len(row),
            axis=1
        ).set_table_styles([
            {'selector': 'th', 'props': [('background-color', primaryColor), ('color', 'white'), ('font-weight', 'bold')]},
            {'selector': 'td', 'props': [('border', f'1px solid {primaryColor}'), ('padding', '0.5rem'), ('white-space', 'pre-wrap'), ('word-wrap', 'break-word')]},
            {'selector': 'tr', 'props': [('max-height', '50px'), ('overflow', 'hidden'), ('text-overflow', 'ellipsis'), ('white-space', 'nowrap')]},
            {'selector': 'table', 'props': [('border-collapse', 'collapse'), ('width', '100%'), ('font-family', 'Arial, sans-serif'), ('font-size', '0.9rem')]}
        ], overwrite=False)
        st.dataframe(styled_data)
        st.markdown("</div>", unsafe_allow_html=True)

    # Download data as CSV
    csv_buffer = io.StringIO()
    filtered_data.to_csv(csv_buffer, index=False)
    csv_bytes = csv_buffer.getvalue().encode('utf-8')

    # Download button
    st.download_button(
        label="Download CSV File",
        data=csv_bytes,
        file_name="data.csv",
        mime="text/csv",
    )

if __name__ == "__main__":
    run_app()